import sys
import os
import importlib.util

if sys.version_info[:2] == (3, 11):
    filename = "libnoe.cpython-311-aarch64-linux-gnu.so"
elif sys.version_info[:2] == (3, 12):
    filename = "libnoe.cpython-312-aarch64-linux-gnu.so"
else:
    raise ImportError(f"Unsupported Python version: {sys.version}")

package_dir = os.path.dirname(__file__)
file_path = os.path.join(package_dir, filename)

if not os.path.exists(file_path):
    raise ImportError(f"Shared library not found: {file_path}")

module_name = "libnoe"
spec = importlib.util.spec_from_file_location(module_name, file_path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

globals().update({
    name: getattr(module, name)
    for name in dir(module)
    if not name.startswith('__')
})