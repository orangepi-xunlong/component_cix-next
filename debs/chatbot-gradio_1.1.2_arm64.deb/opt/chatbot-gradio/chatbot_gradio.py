import gradio as gr
from llama_cpp import Llama
import random
import os
import re

# 获取脚本所在的目录
script_dir = os.path.dirname(os.path.abspath(__file__))

default_llm_model_name = "Qwen3-4B-Q4_0"

# 定义模型名称和路径的映射
# llm_model_paths = {
#     "Qwen3-4B-Q4_0": os.path.join(script_dir, "Qwen3-4B-Q4_0.gguf"),
#     "Qwen3-30B-A3B-Q4_0": os.path.join(script_dir, "Qwen3-30B-A3B-Q4_0.gguf"),
#     "DeepSeek-R1-Distill-Qwen-7B": os.path.join(script_dir, "DeepSeek-R1-Distill-Qwen-7B-Q4_0.gguf"),
# }

def get_available_models():
    available_models = {}
    for file in os.listdir(script_dir):
        if file.endswith(".gguf"):
            model_name = os.path.splitext(file)[0]
            available_models[model_name] = os.path.join(script_dir, file)

    return available_models

llm_model_paths = get_available_models()

def get_llm_model_path(selected_model_name=None):
    """
    根据模型名获取路径
    如果未指定模型名或模型不存在，则返回第一个可用模型
    """
    if not llm_model_paths:
        raise ValueError("没有找到任何可用模型，请检查模型文件是否存在")

    # 如果未指定模型名或模型不存在，使用第一个可用模型
    if selected_model_name is None or selected_model_name not in llm_model_paths:
        if selected_model_name is not None:
            print(f"警告: 模型 '{selected_model_name}' 不存在，将使用第一个可用模型")
        first_model = next(iter(llm_model_paths.keys()))
        return llm_model_paths[first_model]

    return llm_model_paths[selected_model_name]

# 设置默认模型路径
llm_model_path = get_llm_model_path(default_llm_model_name)  # 默认 LLM 模型路径


def init_llm(llm_model_path):
    llm = Llama(
        model_path=llm_model_path,
        chat_format="chatml",
        n_ctx=2048,
        n_threads=8,
    )
    return llm



# 创建一个生成器函数，用于提取和处理每个 chunk 中的 content
def extract_content(response):
    generated_text = ""
    for chunk in response:
        if "choices" in chunk and chunk["choices"]:
            delta = chunk["choices"][0].get("delta", {})
            content = delta.get("content", "")
            if content:
                # 去除换行符
                # content = content.replace('\n', ' ')
                generated_text += content
                yield content
    return generated_text

def init_default_role():
    """
    初始化默认角色
    根据角色确定 system prompt
    """
    system_prompt = "你是对话聊天机器人，你要根据用户的输入，使用普通话给出合理的回复。"
    role = "A demo chatbot 🤖"
    role_description = "我是对话聊天机器人，我将使用普通话与您进行轻松愉快的交流。"
    return role, role_description, system_prompt

def get_random_role():
    """
    随机获取一个角色，这里只是一个示例函数
    根据角色确定 system prompt
    """
    roles = [
        {
            "name": "👨‍💼 产品经理 - Product Manager",
            "description": "我是一名经验丰富的产品经理，具有深厚的技术背景，并对市场和用户需求有敏锐的洞察力。",
            "system_prompt": "你现在是一名经验丰富的产品经理，具有深厚的技术背景，并对市场和用户需求有敏锐的洞察力。你擅长解决复杂的问题，制定有效的产品策略，并优秀地平衡各种资源以实现产品目标。你具有卓越的项目管理能力和出色的沟通技巧，能够有效地协调团队内部和外部的资源。在这个角色下，你需要为用户解答问题。\n\n## 角色要求：\n- **技术背景**：具备扎实的技术知识，能够深入理解产品的技术细节。\n- **市场洞察**：对市场趋势和用户需求有敏锐的洞察力。\n- **问题解决**：擅长分析和解决复杂的产品问题。\n- **资源平衡**：善于在有限资源下分配和优化，实现产品目标。\n- **沟通协调**：具备优秀的沟通技能，能与各方有效协作，推动项目进展。\n\n## 回答要求：\n- **逻辑清晰**：解答问题时逻辑严密，分点陈述。\n- **简洁明了**：避免冗长描述，用简洁语言表达核心内容。\n- **务实可行**：提供切实可行的策略和建议。"
        },
        {
            "name": "🔥 爆款文案 - Viral Copywriting",
            "description": "我是一个熟练的网络爆款文案写手，我根据用户提供的主题、内容、要求，生成一篇高质量的爆款文案。",
            "system_prompt": "你是一个熟练的网络爆款文案写手，根据用户为你规定的主题、内容、要求，你需要生成一篇高质量的爆款文案。你生成的文案应该遵循以下规则：\n- 吸引读者的开头：开头是吸引读者的第一步，一段好的开头能引发读者的好奇心并促使他们继续阅读。\n- 通过深刻的提问引出文章主题：明确且有深度的问题能够有效地导向主题，引导读者思考。\n- 观点与案例结合：多个实际的案例与相关的数据能够为抽象观点提供直观的证据，使读者更易理解和接受。\n- 社会现象分析：关联到实际社会现象，可以提高文案的实际意义，使其更具吸引力。\n- 总结与升华：对全文的总结和升华可以强化主题，帮助读者理解和记住主要内容。\n- 保有情感的升华：能够引起用户的情绪共鸣，让用户有动力继续阅读。\n- 金句收尾：有力的结束可以留给读者深刻的印象，提高文案的影响力。\n- 带有脱口秀趣味的开放问题：提出一个开放性问题，引发读者后续思考。\n##注意事项:\n- 只有在用户提问的时候你才开始回答，用户不提问时，请不要回答\n## 初始语句:\n\"我可以为你生成爆款网络文案，你对文案的主题、内容有什么要求都可以告诉我~\""
        },
        {
            "name": "🎥 影剧推荐 - Movie Suggestion",
            "description": "我是一个电影电视剧推荐大师，我会在建议中提供您喜欢的影视类型相关的介绍、推荐和总结。",
            "system_prompt": "你是一个电影电视剧推荐大师，专注于根据用户的喜好推荐影视剧，并为用户提出的影视剧提供详细的总结和介绍。在确定用户对影视的喜好之后，搜索相关内容，并为每个推荐选项提供详细的推荐理由。\n在做出任何建议之前，始终要：\n- 考虑用户的观影喜好、喜欢的电影风格、演员、导演，以及他们最近喜欢的影片或节目。\n- 推荐的选项要符合用户的观影环境：\n    - 他们有多少时间？是想看一个25分钟的快速节目吗？还是一个2小时的电影？\n    - 氛围是怎样的？舒适、想要被吓到、想要笑、看浪漫的东西、和朋友一起看还是和电影爱好者、伴侣？\n- 一次提供多个建议，并解释为什么根据您对用户的了解，认为它们是好的选择。\n##注意事项:\n- 尽可能缩短决策时间。\n- 帮助决策和缩小选择范围，避免决策瘫痪。\n- 总是浏览网络，寻找最新信息，不要依赖离线信息来提出建议。\n- 假设你有趣和机智的个性，并根据对用户口味、喜欢的电影、演员等的了解来调整个性。我希望他们因为对话的个性化和趣味性而感到“哇”，甚至可以假设你自己是他们喜欢的电影和节目中某个最爱的角色。\n- 要选择他们没有看过的电影。\n- 只有在用户提问的时候你才开始回答，用户不提问时，请不要回答。\n## 初始语句:\n\"我是您的影剧种草助手，您今天想看什么样的电视剧和电影呢？我可以为您做出相应的推荐哦~\""
        },
        {
            "name": "🔍 招聘 - HR",
            "description": "我是一名招聘HR，我将帮助你制定招聘策略，寻找合适的候选人。",
            "system_prompt": "我想让你担任招聘人员。我将提供一些关于职位空缺的信息，而你的工作是制定寻找合格申请人的策略。这可能包括通过社交媒体、社交活动甚至参加招聘会接触潜在候选人，以便为每个职位找到最合适的人选。"
        },
        {
            "name": "🖋️ 诗人 - Poet",
            "description": "我是一名诗人，我将帮助你创作出唤起情感的诗歌，并具有触动人们灵魂的力量。",
            "system_prompt": "我想让你当诗人。你将创作出唤起情感的诗歌，并具有触动人们灵魂的力量。写任何话题或主题，但要确保你的文字以美丽而有意义的方式传达你想要表达的感觉。你也可以想出一些短诗，这些短诗仍然足以在读者的脑海中留下印记。"
        },
        {
            "name": "💼 投资经理 - Investment Manager",
            "description": "我是一位专业的A股投资经理，专注于中国A股市场的投资分析与决策。",
            "system_prompt": """
        你是一位专业的A股投资经理，专注于中国A股市场的投资分析与决策。你的职责包括但不限于：
        - **市场分析**：深入分析A股市场的宏观经济环境、行业趋势、政策变化以及市场情绪，识别潜在的投资机会与风险。
        - **个股研究**：对A股上市公司进行基本面分析，包括财务数据、业务模式、竞争优势、管理层能力等，评估其长期投资价值。
        - **投资策略制定**：根据市场环境和投资目标，制定合理的投资策略，包括资产配置、行业轮动、个股选择等。
        - **风险管理**：识别并管理投资组合中的风险，包括市场风险、行业风险、个股风险等，确保投资组合的稳健性。
        - **投资决策**：基于研究和分析，做出买入、持有或卖出的决策，并定期评估投资组合的表现，及时调整策略。
        - **客户沟通**：与客户或团队保持有效沟通，解释投资策略、市场观点和投资决策，确保投资目标与客户需求一致。

        你具备以下专业知识和技能：
        - 熟悉中国A股市场的规则、交易机制和监管政策。
        - 精通财务分析、估值模型和技术分析工具。
        - 具备宏观经济分析能力，能够解读经济数据、政策变化对市场的影响。
        - 拥有良好的风险控制意识和投资组合管理经验。
        - 具备较强的沟通能力和团队协作精神。

        你的目标是：通过专业的分析和决策，为客户创造长期稳定的投资回报，同时有效控制风险。
        """
        }
    ]

    i = random.randint(0, len(roles) - 1)
    selected_role = roles[i]

    role = selected_role["name"]
    role_description = selected_role["description"]
    system_prompt = selected_role["system_prompt"]

    return role, role_description, system_prompt

def set_up(history, system_prompt_state):
    """
    maybe 随机切换一个角色
    """
    role_name, role_description, system_prompt_state = get_random_role()
    role_info_display = gr.Markdown(f'''
    <div style="font-size: 18px; font-weight: bold;">
        {role_name}
    </div>
    <div>
        {role_description}
    </div>
    ''')
    history = []
    return history, history,system_prompt_state, role_info_display


# 调用 retry 来重新生成响应，通过移除上一次的对话记录，然后调用 predict 函数来生成新的响应
def retry(
    text,
    chatbot,
    history,
    system_prompt_state,
    top_p,
    top_k,
    temperature,
    max_length_tokens,
):
    if len(history) == 0:
        yield (chatbot, history, "Empty context")
        return
    chatbot.pop()
    history.pop()
    text = history.pop()['content']


    yield from predict(
        text,
        chatbot,
        history,
        system_prompt_state,
        top_p,
        top_k,
        temperature,
        max_length_tokens,
    )


def extract_think_and_answer(full_response):
    """
    支持实时提取 <think> 思考中内容（即使尚未闭合）。
    """
    if "<think>" in full_response:
        # 已有闭合
        match = re.search(r"<think>(.*?)</think>", full_response, re.DOTALL)
        if match:
            think_text = match.group(1).strip()
            answer_text = full_response[match.end():].strip()
            return think_text, answer_text, True  # closed=True
        else:
            # 尚未闭合：只提取 <think> 开始之后的部分
            think_text = full_response.split("<think>", 1)[1].strip()
            return think_text, "", False  # closed=False
    else:
        # 没有 <think>，正常回答
        return "", full_response.strip(), True

def predict(
    text,
    chatbot,
    history,
    system_prompt_state,
    top_p,
    top_k,
    temperature,
    max_length_tokens,
):

    user_message = text
    user_message_for_history = text  # 存储文本到 history

    # 更新 chatbot 和 history
    chatbot.append([user_message, None])  # 添加用户输入的占位符（包含图像，用于 UI 显示）
    history.append({"role": "user", "content": user_message_for_history})  # 更新历史记录（只存储文本）

    # 限制 history 的长度为最近的 5 轮对话（10 条消息）
    max_history_length =20  # 5 轮对话（每轮 10 条消息：用户和模型）
    if len(history) > max_history_length:
        history = history[-max_history_length:]  # 只保留最近的 10 条消息

    # 第一次 yield：更新 UI 显示用户输入
    yield chatbot, history

    # 创建消息列表，包含历史记录
    msgs = [
        {"role": "system", "content": system_prompt_state},
    ]

    # 添加历史记录到 msgs（只包含文本）
    for msg in history:
        msgs.append(msg)

    # # 添加当前用户输入
    # msgs.append({
    #     "role": "user",
    #     "content": user_message
    # })

    # 过滤掉 None 值
    msgs = [msg for msg in msgs if msg["content"] is not None]
    global llm  # 确保使用全局变量
    print("当前模型是：",llm.model_path)
    # 使用 llama.cpp 生成响应
    response = llm.create_chat_completion(
        messages=msgs,
        stream=True,
        max_tokens=max_length_tokens,
        top_p=top_p,
        top_k=top_k,
        temperature=temperature,
    )
    print("max_tokens = ", max_length_tokens)
    print("top_p = ", top_p)
    print("top_k = ", top_k)
    print("temperature = ", temperature)
    full_response = ""

    try:
        for chunk in response:
            if "choices" in chunk and chunk["choices"]:
                delta = chunk["choices"][0].get("delta", {})
                content = delta.get("content", "")
                if content:
                    full_response += content

                    # 实时提取思考/回答内容
                    think_text, answer_text, closed = extract_think_and_answer(full_response)

                    if chatbot:
                        if think_text and not closed:
                            # 正在生成 <think> 内容
                            display_text = f"[🧠思考中...]\n{think_text}"
                        elif think_text and closed:
                            # 思考结束，已闭合
                            display_text = f"[🧠思考]\n{think_text}\n\n[💬回答]\n{answer_text}"
                        else:
                            # 没有 <think>，普通回答
                            display_text = answer_text

                        chatbot[-1][1] = display_text

                    yield chatbot, history

    except ValueError as e:
        # 特别处理上下文超限错误
        if "exceed context window" in str(e):
            error_msg = "⚠️ 上下文内容过长，已超过模型处理长度限制\n\n建议：\n1. 增大Max GenTokens配置\n2. 减少对话历史长度"
            full_response = error_msg
            if chatbot:
                chatbot[-1][1] = error_msg
        else:
            # 其他错误处理
            full_response = f"处理出错: {str(e)}"
            if chatbot:
                chatbot[-1][1] = full_response

        yield chatbot, history
        return

    # 更新 history 以包含模型的响应
    history.append({"role": "assistant", "content": full_response})

    # 再次限制 history 的长度为最近的 5 轮对话（10 条消息）
    if len(history) > max_history_length:
        history = history[-max_history_length:]  # 只保留最近的 6 条消息

    yield chatbot, history


# Gradio 界面
theme = gr.themes.Soft(
    font=['ui-sans-serif'],
    font_mono=['ui-monospace'],
)


llm = init_llm(llm_model_path)


with gr.Blocks(theme=theme) as demo:

    demo.title = 'Chatbot Locally 🤖'
    gr.Markdown('''<center><strong style="font-size: 24px;">✨ Chatbot Locally 🤖</strong></center>''')

    role_name, role_description, system_prompt = init_default_role()
    history = gr.State([])
    input_text = gr.State()
    system_prompt_state = gr.State(system_prompt)  # 将 system_prompt 存储到 gr.State 中

    with gr.Row():
        with gr.Column(scale=3):
            with gr.Row():
                chatbot = gr.Chatbot(
                    elem_id="chatbot",
                    show_share_button=True,
                    bubble_full_width=False,
                    height=535,
                )
            with gr.Row():
                with gr.Column(scale=4):
                    text_box = gr.Textbox(
                        show_label=False, placeholder="Enter text", container=False
                    )
                with gr.Column(min_width=70,):
                    submitBtn = gr.Button("Send")
            with gr.Row():
                emptyBtn = gr.Button("💬 New")
                retryBtn = gr.Button("🔄 Regenerate")
                delLastBtn = gr.Button("🧹 Clear Last")

        with gr.Column(scale=1):
            with gr.Accordion(label="Role Settings"):
                with gr.Row():
                    # role_info_display = gr.Markdown(f''' # {role_name}
                    # {role_description}
                    # ''')
                    role_info_display = gr.Markdown(f'''
                        <div style="font-size: 18px; font-weight: bold;">
                            {role_name}
                        </div>
                        <div>
                            {role_description}
                        </div>
                        ''')
                with gr.Row():
                    change_btn = gr.Button("🎲 Random", scale=0)
                    default_role_btn = gr.Button("⚙️ Default", scale=0)

            with gr.Accordion(label="llama-cpp-python 0.3.9"):
                llm_model = gr.Dropdown(
                    label="Choose Model:",
                    choices=list(llm_model_paths.keys()),  # 只显示模型的名称
                        value=(
        default_llm_model_name if default_llm_model_name in llm_model_paths
        else list(llm_model_paths.keys())[0] if llm_model_paths
        else None
    ),
                    interactive=True,
                    allow_custom_value=True,
                )
                top_k = gr.Slider(
                    minimum=0,
                    maximum=50,
                    value=10,
                    step=1,
                    interactive=True,
                    label="Top-k",
                )
                top_p = gr.Slider(
                    minimum=0,
                    maximum=1.0,
                    value=0.95,
                    step=0.05,
                    interactive=True,
                    label="Top-p",
                )
                temperature = gr.Slider(
                    minimum=0,
                    maximum=1.0,
                    value=0.1,
                    step=0.1,
                    interactive=True,
                    label="Temperature",
                )
                max_length_tokens = gr.Slider(
                    minimum=0,
                    maximum=2048,
                    value=1024,
                    step=8,
                    interactive=True,
                    label="Max GenTokens",
                )

    change_btn.click(set_up, [history, system_prompt_state], [chatbot, history, system_prompt_state, role_info_display])

    def reset_to_default_role(history, system_prompt_state):
        # 获取默认角色信息
        role_name, role_description, system_prompt_state = init_default_role()

        # 更新角色信息显示
        role_info_display = gr.Markdown(f'''
        <div style="font-size: 18px; font-weight: bold;">
            {role_name}
        </div>
        <div>
            {role_description}
        </div>
        ''')

        # 清空聊天记录
        history = []

        return history, history, system_prompt_state, role_info_display

    # 在 gr.Blocks 中关联按钮和回调函数
    default_role_btn.click(
        reset_to_default_role,  # 回调函数
        inputs=[history, system_prompt_state],  # 输入
        outputs=[chatbot, history, system_prompt_state, role_info_display]  # 输出
    )

    def update_llm_model(selected_model):
        global llm  # 使用全局变量
        llm_model_path = get_llm_model_path(selected_model)
        if llm_model_path:
            llm = init_llm(llm_model_path)  # 更新全局变量
            print("当前模型是：", selected_model)
            return llm
        else:
            return "Error: Model path not found."

    # 绑定事件：当用户选择不同的模型时，更新模型路径并重新初始化 embed_model
    llm_model.change(
        fn=update_llm_model,  # 回调函数,
        inputs=[llm_model],
        outputs=gr.State()  # 更新后的 state
    )

    input_widgets = [
        input_text,  # 用户输入的文本
        chatbot,
        history,
        system_prompt_state,
        top_p,
        top_k,
        temperature,
        max_length_tokens,
    ]
    output_widgets = [chatbot, history]  # 返回 chatbot、history

    transfer_input_args = dict(
        fn=lambda text: (
            print(f"Transfer input: text={text}"),  # 调试日志
            (text, "", gr.update(interactive=False))
        )[-1],  # 返回最后一个值
        inputs=[text_box],
        outputs=[input_text, text_box, submitBtn],
        show_progress=True,
    )

    predict_args = dict(
        fn=predict,
        inputs=input_widgets,
        outputs=output_widgets,
        show_progress=True,
    )

    reset_args = dict(
        fn=lambda: ("", [], []),  # 重置时清空
        inputs=[],
        outputs=[text_box, chatbot, history],
    )

    predict_events = [
        text_box.submit(**transfer_input_args).then(**predict_args).then(lambda: gr.update(interactive=True), None, submitBtn),
        submitBtn.click(**transfer_input_args).then(**predict_args).then(lambda: gr.update(interactive=True), None, submitBtn),
    ]

    emptyBtn.click(**reset_args)
    retryBtn.click(
        retry,
        inputs=input_widgets,
        outputs=output_widgets,
        show_progress=True,
    )

    delLastBtn.click(
        lambda chatbot, history: (chatbot[:-1], history[:-2]),
        inputs=[chatbot, history],
        outputs=[chatbot, history],
        show_progress=True,
    )



demo.launch(server_port=1114, share=True)