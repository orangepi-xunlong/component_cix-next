# chatbot-gradio
🚀 A local chatbot powered by llama-cpp-python0.3.9 🦙

# 🤖 Chat with LLM locally

## 📦 Installation

安装下面两个：
    apt install gcc g++ git
    pip install gradio>=5.29.0
    CMAKE_ARGS="-DGGML_NATIVE=OFF" pip install llama_cpp_python==0.3.9

model path:
    将目标llm 模型存放到当前目录下;
    例如：将Qwen3-7B-Q4_0.gguf下载后放在当前目录

Usage:
    1.运行脚本文件：
        在终端中执行 python3 chatbot_gradio.py
    2.在浏览器(推荐使用Firefox浏览器)中打开显示的本地URL，即可进行交互。
    3.关闭脚本文件：
        在终端中按下 Ctrl + C

## 参数说明
Top-k
    调大：增加词汇选择范围，生成结果更丰富但可能降低相关性；调小：缩小词汇选择范围，生成结果更集中但可能缺乏多样性。
Top-p
    调大：扩大词汇选择的动态范围，提升生成的灵活性；调小：缩小词汇选择范围，使生成更保守、更可靠。
Temperature
    调高：使生成结果更随机、更具创造性；调低：使生成结果更稳定、更可预测。
Max GenTokens
    调大：允许生成更长的文本，适合复杂任务；调小：限制生成文本长度，节省资源，适合简单任务。
