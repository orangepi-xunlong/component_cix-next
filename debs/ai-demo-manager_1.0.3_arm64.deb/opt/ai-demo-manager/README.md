# ai-demo-manager
✨ CIX AI Experience Control Center ✨

pip install -r requirements.txt

Usage:
    1.运行脚本文件：
        在终端中执行 python3 manager.py
    2.在浏览器(推荐使用Firefox浏览器)中打开显示的本地URL，即可进行交互。
    3.关闭脚本文件：
        在终端中按下 Ctrl + C
    4.如果需要添加新的ai demo，直接修改demos.yaml文件中的demos列表，然后重新运行脚本文件即可。
    5.针对vscode_continue这个应用，本manager中启动是其后端的server，url为：http://localhost:1119/，且需要在demos.yaml文件的models中修改vscode_continue_model_path的值，为该model的绝对路径
    6.支持使用 --config 参数来加载指定的yaml文件，进而生成相应的demo：
        python3 manager.py  #默认加载default.yaml文件，内含 文生图sd、VScode Coding Assistant、PicQuery-cn、ChatBot
        python3 manager.py --config demos.yaml  #指定加载demo.yaml文件
