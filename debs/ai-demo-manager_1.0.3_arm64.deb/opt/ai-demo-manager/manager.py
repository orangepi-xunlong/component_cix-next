import re
import gradio as gr
import yaml
import subprocess
from psutil import process_iter
from concurrent.futures import ThreadPoolExecutor
import time
import logging
import os
import socket
import webbrowser
import threading
import argparse

# 初始化日志
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

script_dir = os.path.dirname(os.path.abspath(__file__))

def load_config(config_path):
    """加载YAML配置文件"""
    with open(config_path) as f:
        return yaml.safe_load(f)

running_procs = {}
executor = ThreadPoolExecutor(max_workers=5)

# 组件容器（按卡片存储）
components = {
    "tabs": [],
    "cards": []  # 每个卡片包含{name, desc, launch, stop, status}
}

def is_port_in_use(port: int) -> bool:
    """检测指定端口是否已被监听"""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)  # 设置超时避免长时间阻塞
        try:
            s.connect(("127.0.0.1", port))
            return True
        except (ConnectionRefusedError, socket.timeout):
            return False
        except Exception as e:
            logging.error(f"端口检测异常: {e}")
            return False

def extract_error(error_msg: str) -> str:
    error_lines = error_msg.splitlines()
    error_pattern = re.compile(r'^(\w+Error): ')
    
    for line in reversed(error_lines):
        if match := error_pattern.match(line):
            return line.strip()
    return error_lines[-1].strip() if error_lines else "Unknown Error"

def launch_demo(script_path, port, lang):
    if script_path == os.path.join(script_dir, "VScode-Continue"):
        if script_path in running_procs:
            return f"🟢 Running | (Existing) http://localhost:{port}" if lang == "en" else f"🟢 运行中 | (已有实例) http://localhost:{port}"
        command = ["taskset", "-c", "0,5,6,7,8,9,10,11", 
            "/usr/share/cix/bin/llama-server", 
            "--port", str(port), "-m", vscode_continue_model_dir, "-t", "8", "-c", "4096"]
    else:
        if not os.path.exists(script_path):
            logging.error(f"脚本 {script_path} 不存在")
            return f"❌ Script not found" if lang == "en" else f"❌ 脚本不存在"
            
        if script_path in running_procs:
            return f"🟢 Running | (Existing) http://localhost:{port}" if lang == "en" else f"🟢 运行中 | (已有实例) http://localhost:{port}"

        command = ["streamlit", "run", script_path, "--server.port", str(port)] if "streamlit" in script_path else ["python3", script_path, "--server_port", str(port)]
    try:
        proc = subprocess.Popen(
            command,
            stdout=None,
            stderr=subprocess.PIPE,  # 必须显式指定管道
            bufsize=0,               # 关闭缓冲
        )
        running_procs[script_path] = proc
        logging.info(f"尝试启动 {script_path}，端口 {port}...")
        
        for _ in range(10):
            time.sleep(1)
            if proc.poll() is not None:
                _, stderr_data = proc.communicate()
                error = extract_error(stderr_data.decode(errors='replace'))
                logging.error(f"❌ 进程异常退出: {error}")
                return f"❌ {error}"
            if is_port_in_use(port):
                logging.info(f"端口 {port} 已生效!")
                return f"🟢 Running | http://localhost:{port}" if lang == "en" else f"🟢 运行中 | http://localhost:{port}"
                
        proc.terminate()
        del running_procs[script_path]
        logging.error(f"启动超时: 端口 {port} 未生效")
        return "❌ Startup timeout" if lang == "en" else "❌ 启动超时"
    except Exception as e:
        logging.error(f"启动失败: {str(e)}")
        return "❌ Launch failed" if lang == "en" else "❌ 启动失败"

def launch_and_open_url(script_path, port, lang):
    result = launch_demo(script_path, port, lang)
    if "Running" in result or "运行中" in result:
        threading.Thread(target=lambda: webbrowser.open(f"http://localhost:{port}")).start()
    return result

def stop_demo(script_path, lang):
    if script_path in running_procs:
        logging.info(f"正在终止脚本 {script_path}。")
        running_procs[script_path].terminate()
        del running_procs[script_path]
        logging.info(f"脚本 {script_path} 已成功终止。")
    else:
        logging.warning(f"脚本 {script_path} 未在运行，无法终止。")
    return "🔴 Stopped" if lang == "en" else "🔴 已停止"


# ================== 界面组件重构 ==================
status_components = []  # 状态组件
def create_demo_card(demo):
    """创建结构化的服务卡片"""
    card_components = {
        "demo": demo  # 直接存储demo引用
    }
    with gr.Column(elem_classes="demo-card") as card:
        # 文本区域
        with gr.Column(elem_classes="text-section"):
            card_components["name"] = gr.Markdown(
                f"## {demo.get('icon', '')} {demo['name']['zh']}",
                elem_classes="demo-name"
            )
            card_components["desc"] = gr.Markdown(
                f'<div class="description-box">{demo["description"]["zh"]}</div>',
                elem_classes="demo-desc"
            )
        
        # 控制区域
        with gr.Row(elem_classes="control-section"):
            card_components["launch"] = gr.Button(
                value="启动" if current_lang.value == "zh" else "Launch",
                interactive=True,
                variant="primary"
            )
            card_components["stop"] = gr.Button(
                value="停止" if current_lang.value == "zh" else "Stop"
            )
            card_components["status"] = gr.Markdown("🔴 未运行" if current_lang.value == "zh" else "🔴 Not running", elem_classes="status-md")

        # 事件绑定（保持原有逻辑）
        card_components["launch"].click(
            fn=launch_and_open_url,
            inputs=[gr.State(demo["script"]), gr.State(demo["port"]), current_lang],
            outputs=card_components["status"]
        )
        card_components["stop"].click(
            fn=stop_demo,
            inputs=[gr.State(demo["script"]), current_lang],
            outputs=card_components["status"]
        )

    components["cards"].append(card_components)
    status_components.append(card_components["status"])  # 收集状态组件
    return card

def update_language(lang, *status_values):
    """结构化语言更新逻辑"""
    new_lang = "zh" if lang == "en" else "en"
    updates = []

    # ======= 第一部分：更新标题和按钮 ======= 
    updates.append(
        gr.HTML(value="<h1 style='font-weight: 500; margin-bottom: 0.25em;'>✨ CIX AI Experience Control Center ✨</h1>" 
                if new_lang == "en" 
                else "<h1 style='font-weight: 500; margin-bottom: 0.25em;'>✨ CIX AI 体验控制中心 ✨</h1>")
    )
    updates.append("Switch to Chinese" if new_lang == "en" else "切换语言 / Switch to English")

    updates += [
        gr.update(label=f" 📁 {cat[new_lang]} ")
        for cat in sorted_categories
    ]

    for i, card in enumerate(components["cards"]):
            demo = card["demo"]
            current_status = status_values[i]  # 获取传入的当前状态值
            # 1. 更新名称和描述（直接读取配置）
            updates.append(f"## {demo.get('icon', '')} {demo['name'][new_lang]}")
            updates.append(f'<div class="description-box">{demo["description"][new_lang]}</div>')

            # 2. 更新按钮文本
            updates.append("Launch" if new_lang == "en" else "启动")
            updates.append("Stop" if new_lang == "en" else "停止")

            # 3. 翻译状态文本
            status_display = translate_status_text(current_status, new_lang)
            updates.append(status_display)
    return [new_lang] + updates

def translate_status_text(text: str, target_lang: str) -> str:
    parts = text.split(" ", 1)
    icon = parts[0] if len(parts) > 0 else ""
    content = parts[1] if len(parts) > 1 else ""

    # 翻译映射表（可根据需要扩展）
    translations = {
        "zh": {
            "Running": "运行中",
            "Stopped": "已停止",
            "Not running": "未运行",
            "Startup timeout": "启动超时",
            "Launch failed": "启动失败",
            "Script not found": "脚本不存在",
        },
        "en": {
            "运行中": "Running",
            "已停止": "Stopped",
            "未运行": "Not running",
            "启动超时": "Startup timeout",
            "启动失败": "Launch failed",
            "脚本不存在": "Script not found",
        }
    }

    # 保留URL部分（| 后的内容）
    if "|" in content:
        status_part, url_part = content.split(" | ", 1)
        status_part = status_part.strip()
        url_part = " | " + url_part.strip()
    else:
        status_part = content.strip()
        url_part = ""

    # 执行翻译
    if target_lang == "en":
        translated = next(
            (en for zh, en in translations["en"].items() if zh in status_part),
            status_part  # 找不到翻译则保留原文
        )
    else:
        translated = next(
            (zh for en, zh in translations["zh"].items() if en in status_part),
            status_part
        )

    return f"{icon} {translated}{url_part}"

css = """
/* 卡片布局 */
.demo-card {
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    padding: 20px;
    margin: 15px 0;
    background: white;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    display: flex !important;
    flex-direction: column;
    gap: 15px;
}
.demo-card:hover {
    transform: translateY(-3px);
}
/* 通过 flex 容器实现垂直居中 */
.vertical-center {
    align-items: center !important;
    min-height: 40px; /* 匹配按钮高度 */
}

/* 文本区域 */
.text-section {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.demo-name {
    font-size: 1.3em !important;
    margin: 0 !important;
    font-weight: 600;
    color: #1a1a1a;
}

.demo-desc {
    font-size: 0.95em !important;
    color: #666;
    margin: 0 !important;
    line-height: 1.5;
}

/* 控制区域 */
.control-section {
    display: flex;
    justify-content: space-between;
    align-items: center !important;
    min-height: 40px; /* 匹配按钮高度 */
    gap: 15px;
}

.status-md {
    margin: 0 !important;
    padding: 5px 0 !important; /* 保持与按钮相似的垂直间距 */
    line-height: 1.2 !important; /* 优化文本基线对齐 */
}

/* 分类标签页 */
.custom-tabs {
    gap: 0.5rem !important;  /* 控制相邻Tab间距 */
    background: linear-gradient(145deg, #f8f9fa, #ffffff);
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.05);
}

.category-tab {
    font-size: 1.8rem !important;    /* 字体大小调整 */
    font-weight: 600;
    letter-spacing: 1px !important;
    padding: 12px 24px;
    transition: all 0.3s ease;
    border-bottom: 2px solid transparent;
}

.category-tab:hover {
    background: rgba(100, 149, 237, 0.1);
}
/* 选中状态强化 */
.category-tab[selected] {
    font-size: 2rem !important; /* 选中时更大字体 */
    letter-spacing: 1.2px;
    background: #3b82f6 !important;
    color: white !important;
    box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.3);
}

/* 悬停交互效果 */
.category-tab:not([selected]):hover {
    background: #eff6ff !important;
    transform: translateY(-2px);
}
.description-box {
    padding: 12px;
    background: rgba(240, 240, 240, 0.3);
    border-radius: 6px;
    margin: 8px 0;
    border-left: 3px solid #6495ed;
}
.title {
    font-size: 100px !important;
}
.lang_btn {
    min-width: 100px !important;
    padding: 8px 12px !important;
    transition: all 0.2s ease !important;
    border-radius: 8px !important;
}
.lang_btn:hover {
    transform: scale(1.05);
    box-shadow: 0 4px 6px -1px rgba(59, 130, 246, 0.3);
}
"""


if __name__ == "__main__":
    # 配置命令行参数解析
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", 
                        default=os.path.join("default.yaml"),  # 默认路径
                        help="Path to config YAML file (relative to script dir)")
    args = parser.parse_args()

    # 构建完整配置文件路径
    config_path = os.path.join(script_dir, args.config)

    # 加载配置
    config = load_config(config_path)
    # 预处理分类（按英文名称排序）
    sorted_categories = sorted(
        {demo["category"]["en"]: demo["category"] for demo in config["demos"]}.values(),
        key=lambda x: x["en"]
    )
    for demo in config["demos"]:
        demo["script"] = os.path.abspath(os.path.join(script_dir, demo["script"]))
    vscode_continue_model_dir = config["models"]["vscode_continue_model_path"]

    # ================== 界面布局 ==================
    with gr.Blocks(css=css, theme=gr.themes.Soft()) as app:
        current_lang = gr.State("zh")
        
        with gr.Row():
            with gr.Column(scale=2):
                title = gr.HTML("""<h1 style="font-weight: 650; margin-bottom: 0.25em;">✨ CIX AI 体验控制中心 ✨</h1>
            </div>""")
            with gr.Column(scale=1):
                lang_btn = gr.Button(
                    "切换语言 / Switch to English",  # 中文按钮文本
                    elem_classes="lang_btn",
                    size="lg",
                    variant="primary"
                )
        
        # 分类标签页
        tab_components = []
        with gr.Tabs(elem_classes="custom-tabs") as tabs_container:
            for category in sorted_categories:
                with gr.Tab(label=" 📁 "+category["zh"], elem_classes="category-tab") as tab:
                    tab_components.append(tab)
                    with gr.Column():
                        for demo in config["demos"]:
                            if demo["category"]["en"] == category["en"]:
                                create_demo_card(demo)
        
        # 语言切换
        lang_btn.click(
            fn=update_language,
            inputs=[current_lang] + status_components,  # 将当前所有状态值作为输入
            outputs=[current_lang, title, lang_btn] +
                tab_components +
                [comp for card in components["cards"] for comp in (card["name"], card["desc"], card["launch"], card["stop"], card["status"])]
        )
    app.launch(server_port=7860)