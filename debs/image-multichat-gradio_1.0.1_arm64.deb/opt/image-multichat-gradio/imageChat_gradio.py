import base64
from io import BytesIO
import gradio as gr
from PIL import Image
from llama_cpp import Llama
from llama_cpp.llama_chat_format import MiniCPMv26ChatHandler
import os

# 获取脚本所在的目录
script_dir = os.path.dirname(os.path.abspath(__file__))

# 定义模型名称和路径的映射
llm_model_paths = {
    "Minicpm-7.6B-Q4_0": os.path.join(script_dir, "Minicpm-7.6B-Q4_0.gguf"),
}
clip_model_paths = {
    "mmproj-model-f16": os.path.join(script_dir, "mmproj-model-f16.gguf"),
}

# 获取模型路径的函数
def get_llm_model_path(selected_model_name):
    return llm_model_paths[selected_model_name]

def get_clip_model_path(selected_model_name):
    return clip_model_paths[selected_model_name]

# 设置默认模型路径
default_llm_model_name = "Minicpm-7.6B-Q4_0"
default_clip_model_name = "mmproj-model-f16"

llm_model_path = get_llm_model_path(default_llm_model_name)  # 默认 LLM 模型路径
clip_model_path = get_clip_model_path(default_clip_model_name)  # 默认 clip 模型路径

# 加载模型
def load_models():
    # 加载 llama.cpp 模型
    chat_handler = MiniCPMv26ChatHandler(clip_model_path=clip_model_path)
    llm = Llama(
        model_path=llm_model_path,
        chat_handler=chat_handler,
        chat_format="minicpm-v-2.6",
        n_ctx=2048,  # 上下文长度
        n_threads=8,  # 线程数
    )

    return llm

# 调用 retry 来重新生成响应，通过移除上一次的对话记录，然后调用 predict 函数来生成新的响应
def retry(
    text,
    image,
    chatbot,
    history,
    top_p,
    temperature,
    max_length_tokens,
    model_select_dropdown,
):
    if len(history) == 0:
        yield (chatbot, history, "Empty context")
        return

    chatbot.pop()
    history.pop()
    text = history.pop()[-1]
    if type(text) is tuple:
        text, image = text

    yield from predict(
        text,
        image,
        chatbot,
        history,
        top_p,
        temperature,
        max_length_tokens,
        model_select_dropdown,
    )


# 图像处理
def image_to_base64_data_uri(image, max_size=(400, 400)):
    if isinstance(image, str):  # 如果 image 是文件路径
        with Image.open(image) as img:
            img.thumbnail(max_size)
            buffered = BytesIO()
            img.save(buffered, format="PNG")
            base64_data = base64.b64encode(buffered.getvalue()).decode('utf-8')
            return f"data:image/png;base64,{base64_data}"
    else:  # 如果 image 是 PIL.Image 对象
        image.thumbnail(max_size)
        buffered = BytesIO()
        image.save(buffered, format="PNG")
        base64_data = base64.b64encode(buffered.getvalue()).decode('utf-8')
        return f"data:image/png;base64,{base64_data}"


def predict(
    text,
    image,
    chatbot,
    history,
    top_p,
    top_k,
    temperature,
    max_length_tokens,
):
    print(f"Predict input: text={text}, image={image}")  # 调试日志

    try:
        llm = model

        if not text.strip():  # 检查文本是否为空或只有空格
            print("Empty text input.")  # 调试日志
            yield chatbot, history  # 返回 chatbot、history
            return
    except KeyError:
        print("No model found.")  # 调试日志
        yield [[text, "No Model Found"]], []  # 返回 chatbot、history
        return

    # 处理图像
    if image is not None:  # 如果用户上传了新图片
        data_uri = image_to_base64_data_uri(image)
        image_str = f'<img src="{data_uri}" alt="user upload image" style="max-width: 300px; max-height: 300px; object-fit: contain; display: block; margin: 0 auto;" />'
        user_message_with_image = f"{image_str}{text}"  # 将图片和文本组合（用于 UI 显示）
        user_message_for_history = text  # 只存储文本到 history
    else:  # 如果没有上传图片
        image = None
        user_message_with_image = text  # 如果没有图片，只显示文本
        user_message_for_history = text  # 只存储文本到 history

    # 更新 chatbot 和 history
    chatbot.append([user_message_with_image, None])  # 添加用户输入的占位符（包含图像，用于 UI 显示）
    history.append({"role": "user", "content": user_message_for_history})  # 更新历史记录（只存储文本）

    # 限制 history 的长度为最近的 3 轮对话（6 条消息）
    max_history_length = 10  # 3 轮对话（每轮 2 条消息：用户和模型）
    if len(history) > max_history_length:
        history = history[-max_history_length:]  # 只保留最近的 6 条消息

    # 第一次 yield：更新 UI 显示用户输入
    yield chatbot, history

    # 创建消息列表，包含历史记录
    msgs = [
        {"role": "system", "content": "You are an assistant who perfectly describes images."},
    ]
    
    # 添加历史记录到 msgs（只包含文本）
    for msg in history:
        msgs.append(msg)

    # 添加当前用户输入（包含图像）
    msgs.append({
        "role": "user",
        "content": [
            {"type": "image_url", "image_url": {"url": data_uri}} if image is not None else None,
            {"type": "text", "text": text}
        ]
    })

    # 过滤掉 None 值
    msgs = [msg for msg in msgs if msg["content"] is not None]


    # 使用 llama.cpp 生成响应
    response = llm.create_chat_completion(
        messages=msgs,
        stream=True,
        max_tokens=max_length_tokens,
        top_p=top_p,
        top_k=top_k,
        temperature=temperature,
    )

    full_response = ""
    for chunk in response:
        if "choices" in chunk and chunk["choices"]:
            delta = chunk["choices"][0].get("delta", {})
            content = delta.get("content", "")
            if content:
                full_response += content
                if chatbot:  # 确保 chatbot 列表不为空
                    chatbot[-1][1] = full_response  # 更新最后一个元素的模型响应
                # 实时更新 UI
                yield chatbot, history

    # 更新 history 以包含模型的响应
    history.append({"role": "assistant", "content": full_response})

    # 再次限制 history 的长度为最近的 3 轮对话（6 条消息）
    if len(history) > max_history_length:
        history = history[-max_history_length:]  # 只保留最近的 6 条消息

    yield chatbot, history


# 加载模型
model = load_models()


# Gradio 界面
theme = gr.themes.Soft(
    font=['ui-sans-serif'],
    font_mono=['ui-monospace'],
)

with gr.Blocks(theme=theme) as demo:
    history = gr.State([])
    input_text = gr.State()
    input_image = gr.State()

    demo.title = 'Image Chat 🖼️'
    gr.Markdown('''<center><strong style="font-size: 24px;">✨ Image Chat 🖼️</strong></center>''')

    with gr.Row():
        with gr.Column(scale=1):
            image_box = gr.Image(type="pil")
            
            with gr.Row():
                top_k = gr.Slider(
                    minimum=0,
                    maximum=50,
                    value=10,
                    step=1,
                    interactive=True,
                    label="Top-k",
                )
            with gr.Row():
                top_p = gr.Slider(
                    minimum=0,
                    maximum=1.0,
                    value=0.95,
                    step=0.05,
                    interactive=True,
                    label="Top-p",
                )
            with gr.Row():
                temperature = gr.Slider(
                    minimum=0,
                    maximum=1.0,
                    value=0.1,
                    step=0.1,
                    interactive=True,
                    label="Temperature",
                )
            with gr.Row():
                max_length_tokens = gr.Slider(
                    minimum=0,
                    maximum=2048,
                    value=1024,
                    step=8,
                    interactive=True,
                    label="Max Generation Tokens",
                )

        with gr.Column(scale=4):
            with gr.Row():
                chatbot = gr.Chatbot(
                    elem_id="deepseek_chatbot",
                    show_share_button=True,
                    bubble_full_width=False,
                    height=600,
                )
            with gr.Row():
                with gr.Column(scale=4):
                    text_box = gr.Textbox(
                        show_label=False, placeholder="Enter text", container=False
                    )
                with gr.Column(min_width=70,):
                    submitBtn = gr.Button("Send")
            with gr.Row():
                emptyBtn = gr.Button("💬 New")
                retryBtn = gr.Button("🔄 Regenerate")
                delLastBtn = gr.Button("🧹 Clear Last")

        with gr.Column(scale=1):
            image_test_dir = os.path.join(script_dir, "image_test")
            examples_list = [
                [
                    os.path.join(image_test_dir, "logo1.jpg"),
                    "描述一下这个logo的含义",
                ],
                [
                    os.path.join(image_test_dir, "dog.jpg"),
                    "你觉得图片中的狗狗是什么品种",
                ],                
                [
                    os.path.join(image_test_dir, "R-C.jpg"),
                    "描述一下图片的内容",
                ],                
                [
                    os.path.join(image_test_dir, "2.jpg"),
                    "估算一下图片中食物的卡路里",
                ],                
                [
                    os.path.join(image_test_dir, "3.jpg"),
                    "将图片中的菜单翻译成英文，并以表格形式输出",
                ],                
                [
                    os.path.join(image_test_dir, "4.jpg"),
                    "提前这张发票中的内容，并以表格形式输出",
                ],                
                [
                    os.path.join(image_test_dir, "5.jpg"),
                    "提取图片中的文字内容，并简要概括",
                ],
            ]
            gr.Examples(examples=examples_list, inputs=[image_box, text_box])

    input_widgets = [
        input_text,  # 用户输入的文本
        input_image,  # 用户上传的图片
        chatbot,
        history,
        top_p,
        top_k,
        temperature,
        max_length_tokens,
    ]
    output_widgets = [chatbot, history]  # 返回 chatbot、history 

    transfer_input_args = dict(
        fn=lambda text, image: (
            print(f"Transfer input: text={text}, image={image}"),  # 调试日志
            (text, image, "", None, gr.update(interactive=False)) 
        )[-1],  # 返回最后一个值
        inputs=[text_box, image_box],
        outputs=[input_text, input_image, text_box, image_box, submitBtn],
        show_progress=True,
    )

    predict_args = dict(
        fn=predict,
        inputs=input_widgets,
        outputs=output_widgets,
        show_progress=True,
    )

    reset_args = dict(
        fn=lambda: ("", None, [], [], None),  # 重置时清空 
        inputs=[],
        outputs=[text_box, image_box, chatbot, history],
    )

    predict_events = [
        text_box.submit(**transfer_input_args).then(**predict_args).then(lambda: gr.update(interactive=True), None, submitBtn),
        submitBtn.click(**transfer_input_args).then(**predict_args).then(lambda: gr.update(interactive=True), None, submitBtn),
    ]

    emptyBtn.click(**reset_args)
    retryBtn.click(**predict_args)

    delLastBtn.click(
        lambda chatbot, history: (chatbot[:-1], history[:-2]),
        inputs=[chatbot, history],
        outputs=[chatbot, history],
        show_progress=True,
    )

    

demo.launch(server_port=1111, share=True, allowed_paths=[image_test_dir])